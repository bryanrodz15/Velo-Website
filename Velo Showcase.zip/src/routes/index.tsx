import { createFileRoute } from "@tanstack/react-router";
import { Nav } from "@/components/site/Nav";
import { Hero } from "@/components/site/Hero";
import { Features } from "@/components/site/Features";
import { Analytics } from "@/components/site/Analytics";
import { Community } from "@/components/site/Community";
import { CTA, Footer } from "@/components/site/CTA";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Velo — Your cycling companion" },
      { name: "description", content: "Velo tracks rides, finds bike-safe routes, charts your trends, and remembers the coffee stops." },
      { property: "og:title", content: "Velo — Your cycling companion" },
      { property: "og:description", content: "Track rides, discover routes, and improve your fitness with Velo." },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Nav />
      <main>
        <Hero />
        <Features />
        <Analytics />
        <Community />
        <CTA />
      </main>
      <Footer />
    </div>
  );
}
