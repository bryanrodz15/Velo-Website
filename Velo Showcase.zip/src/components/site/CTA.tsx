export function CTA() {
  return (
    <section id="about" className="py-28 md:py-40 border-t border-border">
      <div className="max-w-3xl mx-auto px-6 text-center">
        <p className="text-sm uppercase tracking-[0.2em] text-muted-foreground mb-6">About Velo</p>
        <h2 className="text-5xl md:text-6xl">
          Built for riders who notice <span className="italic text-accent">the small things</span>.
        </h2>
        <p className="mt-8 text-lg text-muted-foreground leading-relaxed">
          Velo is a cycling companion designed to stay out of the way — quiet on the handlebars, sharp on the data, and always remembering the routes and cafés worth coming back to.
        </p>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-border py-10">
      <div className="max-w-6xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
        <div className="flex items-center gap-2 font-display text-lg text-foreground">
          <span className="inline-block w-2 h-2 rounded-full bg-accent" />
          Velo
        </div>
        <p>© {new Date().getFullYear()} Velo. Ride well.</p>
      </div>
    </footer>
  );
}
