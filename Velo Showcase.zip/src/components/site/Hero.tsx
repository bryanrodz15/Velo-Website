import heroImg from "@/assets/hero-cyclist.jpg";

export function Hero() {
  return (
    <section className="relative pt-32 pb-24 md:pt-44 md:pb-32">
      <div className="max-w-6xl mx-auto px-6 text-center">
        <p className="text-sm uppercase tracking-[0.2em] text-muted-foreground mb-6">
          Your cycling companion
        </p>
        <h1 className="text-5xl md:text-7xl lg:text-8xl leading-[1.02]">
          Every ride,<br />
          <span className="italic text-accent">beautifully</span> measured.
        </h1>
        <p className="mt-8 max-w-xl mx-auto text-lg text-muted-foreground">
          Velo tracks the miles, finds the routes, and remembers the coffee stops —
          so you can focus on the road ahead.
        </p>
      </div>

      <div className="mt-20 max-w-6xl mx-auto px-6">
        <div className="relative rounded-3xl overflow-hidden border border-border shadow-2xl shadow-foreground/5">
          <img
            src={heroImg}
            alt="Cyclist riding a winding mountain road at golden hour"
            width={1920}
            height={1080}
            className="w-full h-auto object-cover"
          />
        </div>
      </div>
    </section>
  );
}
