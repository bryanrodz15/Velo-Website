import { Link } from "@tanstack/react-router";

export function Nav() {
  return (
    <header className="fixed top-0 inset-x-0 z-50 backdrop-blur-md bg-background/70 border-b border-border/50">
      <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 font-display text-xl tracking-tight">
          <span className="inline-block w-2 h-2 rounded-full bg-accent" />
          Velo
        </Link>
        <nav className="hidden md:flex items-center gap-8 text-sm text-muted-foreground">
          <a href="#features" className="hover:text-foreground transition-colors">Features</a>
          <a href="#analytics" className="hover:text-foreground transition-colors">Analytics</a>
          <a href="#community" className="hover:text-foreground transition-colors">Community</a>
        </nav>
        <span className="text-sm text-muted-foreground hidden sm:block">
          Your cycling companion
        </span>
      </div>
    </header>
  );
}
