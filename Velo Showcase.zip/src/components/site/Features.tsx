import { Activity, Map, LineChart, ShoppingBag, Coffee, Users } from "lucide-react";

const features = [
  {
    icon: Activity,
    title: "GPS Ride Tracking",
    body: "Live distance, speed, elevation, and heart-rate zones — captured precisely while you ride.",
  },
  {
    icon: Map,
    title: "Smart Routing",
    body: "Discover bike-safe paths around the city and revisit the routes you've saved.",
  },
  {
    icon: LineChart,
    title: "Trends & Analytics",
    body: "Weekly and monthly dashboards that turn every ride into measurable progress.",
  },
  {
    icon: ShoppingBag,
    title: "Gear Recommendations",
    body: "Personalized equipment suggestions calibrated to your cycling goals.",
  },
  {
    icon: Coffee,
    title: "Coffee Stops",
    body: "Find the best cafés mid-ride and turn every loop into a small adventure.",
  },
  {
    icon: Users,
    title: "Social Rides",
    body: "Share routes, follow friends, and ride together — even when you're apart.",
  },
];

export function Features() {
  return (
    <section id="features" className="py-28 md:py-40 border-t border-border">
      <div className="max-w-6xl mx-auto px-6">
        <div className="max-w-2xl">
          <p className="text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">Features</p>
          <h2 className="text-4xl md:text-5xl">
            Built for riders who notice <span className="italic text-accent">the small things</span>.
          </h2>
        </div>

        <div className="mt-16 grid md:grid-cols-2 lg:grid-cols-3 gap-px bg-border rounded-3xl overflow-hidden border border-border">
          {features.map(({ icon: Icon, title, body }) => (
            <div key={title} className="bg-background p-8 md:p-10 hover:bg-muted/40 transition-colors">
              <Icon className="w-6 h-6 text-accent" strokeWidth={1.5} />
              <h3 className="mt-6 text-2xl">{title}</h3>
              <p className="mt-3 text-muted-foreground leading-relaxed">{body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
