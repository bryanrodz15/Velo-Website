import coffeeImg from "@/assets/feature-coffee.jpg";

export function Community() {
  return (
    <section id="community" className="py-28 md:py-40 border-t border-border">
      <div className="max-w-6xl mx-auto px-6 grid md:grid-cols-2 gap-16 items-center">
        <div className="md:order-2 rounded-3xl overflow-hidden border border-border">
          <img
            src={coffeeImg}
            alt="A coffee, route map, and cycling gloves on a warm tabletop"
            width={1024}
            height={1024}
            loading="lazy"
            className="w-full h-auto object-cover"
          />
        </div>
        <div className="md:order-1">
          <p className="text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">Community</p>
          <h2 className="text-4xl md:text-5xl">
            The ride is better with <span className="italic text-accent">good company</span>.
          </h2>
          <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
            Follow friends, swap routes, and find each other at the café around the corner. Velo keeps the social part of cycling effortless — without ever getting in the way of the ride.
          </p>
        </div>
      </div>
    </section>
  );
}
