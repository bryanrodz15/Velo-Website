import trackingImg from "@/assets/feature-tracking.jpg";

export function Analytics() {
  return (
    <section id="analytics" className="py-28 md:py-40 border-t border-border">
      <div className="max-w-6xl mx-auto px-6 grid md:grid-cols-2 gap-16 items-center">
        <div className="rounded-3xl overflow-hidden border border-border">
          <img
            src={trackingImg}
            alt="Velo app running on a phone mounted to bike handlebars"
            width={1024}
            height={1024}
            loading="lazy"
            className="w-full h-auto object-cover"
          />
        </div>
        <div>
          <p className="text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">On the road</p>
          <h2 className="text-4xl md:text-5xl">A quiet display, a sharp eye on every metric.</h2>
          <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
            Velo's live ride screen surfaces only what matters — pace, heart-rate zone, elevation, and your next turn. The rest stays out of the way.
          </p>

          <div className="mt-10 grid grid-cols-3 gap-6">
            {[
              { k: "1,284", l: "km this month" },
              { k: "Zone 3", l: "average effort" },
              { k: "42", l: "saved routes" },
            ].map((s) => (
              <div key={s.l}>
                <div className="font-display text-3xl">{s.k}</div>
                <div className="text-xs text-muted-foreground uppercase tracking-wider mt-1">{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
